from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5.QtPrintSupport import *
from ui import main, book, layout, detail, cancel
import io, time, threading
from files import train_details as td
from files import distance
from files import high_speed_search as hss
from files import autoTrainFinder as atf
from multiprocessing.pool import ThreadPool as tp
from files import via
import sqlite3

from PyQt5.Qt import QStandardItemModel, QStandardItem


class StandardItem(QStandardItem):
    def __init__(self, txt="", size=10, bold=False, italic=False, color=QColor(0,0,0)):
        super().__init__()

        fnt = QFont("arial", size)
        fnt.setBold(bold)
        fnt.setItalic(italic)
        self.setEditable(False)
        self.setFont(fnt)
        self.setText(txt)
        self.setForeground(color)

class Window(main.Ui_MainWindow, QMainWindow):
    def __init__(self):
        super(Window, self).__init__()
        self.setupUi(self)
        self.setWindowTitle("Train ticket booking panal")

        self.train_name = "shadow exp"
        self.train_no = "99999-unlimited"
        self.station_codes = ["RAH", "AWR"]
        self.stations = ["Ramgarh", "Alwar"]
        self.tticket = 1
        self.distance = 1
        self.timing = [0,0]  #0 7
        self.c_p = ["",1] ### coach class and price
        self.maxTickets = 500
        self.removeData = []

        self.pool = tp(processes=1)
        ### booking window and settings
        self.winBook = book.Ui_MainWindow()
        ### end

        ### trian details
        self.dWin = QMainWindow()
        ### end
        self.setStyleSheet(open("ui\main_style.css").read())
        pixmap = QPixmap("images\\icon.png")
        icon = QIcon(pixmap)
        self.setWindowIcon(icon)

        self.search_trains.clicked.connect(self.from_to)

        comp1 = QCompleter(td.station_name)  ### autocomplete for station names
        comp1.setCaseSensitivity(Qt.CaseInsensitive)
        comp2 = QCompleter(td.train_name)  ### autocomplete for train names
        comp2.setCaseSensitivity(Qt.CaseInsensitive)
        comp3 = QCompleter(td.train_no)  ### autocomplete for train no
        comp3.setCaseSensitivity(Qt.CaseInsensitive)

        self.source.setCompleter(comp1)
        self.dest.setCompleter(comp1)
        self.tname.setCompleter(comp2)
        self.tno.setCompleter(comp3)

        self.bookT.clicked.connect(self.booking)
        self.search.clicked.connect(self.singleTrain)
        self.tdetail.clicked.connect(self.trainDetails)
        self.cancelR.clicked.connect(self.cancelReservation)

        #sh = QShortcut(QKeySequence("Return"),self)
        #sh.activated.connect(self.from_to)

    def booking(self):
        try:
            ind = self.trains.selectedIndexes()
        except:
            ind = 0
        self.train_name = self.trains.item(ind[0].row(),2).text()
        self.train_no = self.trains.item(ind[0].row(),6).text()
        self.timing = [self.trains.item(ind[0].row(),0).text(), self.trains.item(ind[0].row(),7).text()]

        reg_ex = QRegExp("[0-9\.\-]{0,10}")

        self.mainWin = QMainWindow()
        self.winBook.setupUi(self.mainWin)
        self.mainWin.show()
        self.winBook.tickets.setMinimum(1)
        inp_valid = QRegExpValidator(reg_ex,self.winBook.mno)
        self.winBook.mno.setValidator(inp_valid)
        self.mainWin.setStyleSheet(open("ui\\book_style.css").read())
        left = self.maxTickets-self.readData(self.train_name)
        if left<=0:
            self.winBook.confirm.setEnabled(False)
        tleft = "Tickets Left : {}".format(left)
        self.winBook.left.setText(tleft)

        ### settings
        f,t = self.stations
        self.winBook.coach.setCurrentIndex(7)
        self.winBook.fromTo.setText("   From  >  %s  ->  To  >  %s"%(f, t))
        self.distance = distance.distance(self.station_codes[0], self.station_codes[1])
        self.winBook.dist.setText("Distance : %.2f km"%(self.distance))
        self.winBook.tname.setText("Train Name :         %s"%(self.train_name))
        self.winBook.tno.setText("Train No. :          %s"%(self.train_no))
        ind = self.winBook.coach.currentIndex()
        cc = td.coach_codes[0]
        price = td.getTicketPrice(cc, self.distance)
        #self.c_p = [td.coach_names[ind],price*self.tticket]
        self.winBook.price.setText("Price : %d Rs."%(price*self.tticket))
        st,dt = self.timing
        self.winBook.atime.setText("Arrival Time : %s"%(st))
        self.winBook.dtime.setText("Departure Time : %s"%(dt))
        self.hide()

        #### end

        #pixmap = QPixmap()
        icon = QIcon("images\\coach.jpg")
        self.winBook.coach.setIconSize(QSize(50,40))
        for item in td.coach_names:
            self.winBook.coach.addItem(icon, item)

        ### connections
        self.winBook.confirm.clicked.connect(self.confirmBooking)
        self.winBook.tickets.valueChanged.connect(self.booking_data)
        self.winBook.coach.currentIndexChanged.connect(self.booking_data)
        self.winBook.cancel.clicked.connect(self.booking_data)


        #print(self.train_name, self.train_no)
    def confirmBooking(self):
        def accept():
            self.booking_data()
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Question)
        msg.setInformativeText("Are you sure ?")
        msg.setWindowTitle("Confirm Booking")
        msg.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
        retval = msg.exec_()
        if retval==1024:
            accept()
        else:
            pass

    def booking_data(self):
        obj = self.sender().objectName()

        if obj == 'confirm':
            try:
                uname = self.winBook.uname.text()
                mno = self.winBook.mno.text()
                ind = self.winBook.coach.currentIndex()
                cc = td.coach_codes[ind]
                p = td.getTicketPrice(cc, self.distance)
                info = [uname, mno, self.train_name, self.train_no, self.station_codes[0], self.station_codes[1], self.tticket, str(cc), str(p)]
                t1 = threading.Thread(target=self.save_data, args=(info,), kwargs={'mode' : "w"})
                t1.start()
                #time.sleep(1)

                threading.Thread(target=self.save_data, args=(info,), kwargs={'mode' : "wa",}).start()

                self.loutWin = QMainWindow()
                self._ticket = layout.Ui_MainWindow()
                self._ticket.setupUi(self.loutWin)
                self.loutWin.show()
                self._ticket.cancel.setText("Close")

                m = mno[0:4]+"x"*6
                f,t = self.stations
                code, code_to = self.station_codes
                a,d = self.timing
                #c,p = self.c_p
                ind = self.winBook.coach.currentIndex()
                cc = td.coach_codes[ind]
                c = td.coach_names[ind]
                p = td.getTicketPrice(cc, self.distance)

                self._ticket.view.setHtml("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:\'MS Shell Dlg 2\';\"><br /></p>\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:600; color:#e87613;\">NAME                        :  %s</span></p>\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:600; color:#e87613;\">MOBILE NO.             :  %s</span></p>\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:600; color:#e87613;\">FROM                       :  %s (%s)</span></p>\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:600; color:#e87613;\">TO                             :  %s (%s)</span></p>\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:600; color:#e87613;\">TRAIN  NO .             :  %s</span></p>\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:600; color:#e87613;\">TRAIN NAME           :  %s</span></p>\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:600; color:#e87613;\">DISTANCE                :  %.2f km</span></p>\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:600; color:#e87613;\">ARRIVAL TIME       :  %s</span></p>\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:600; color:#e87613;\">DEPARTURE TIME  :  %s</span></p>\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:600; color:#e87613;\">TICKETS                   :  %s</span></p>\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:600; color:#e87613;\">COACH  CLASS        :  %s</span></p>\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:600; color:#e87613;\">PRICE                       :  %.2f Rs.</span></p>\n"
"<p align=\"justify\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:600; color:#e87613;\"><br /></p>\n"
"<p align=\"justify\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:600; color:#e87613;\"><br /></p>\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:600; color:#ad15e8;\">                        </span><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:10pt; font-weight:600; color:#0a0c87;\">validate by :</span><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:14pt; font-weight:600; color:#ad15e8;\"> </span><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:14pt; font-weight:600; color:#1b006f;\">SHADOW</span></p></body></html>"%(uname, m, f, code, t, code_to, self.train_no, self.train_name, self.distance, a, d, str(self.tticket),c ,p))
                self._ticket.print.clicked.connect(self.layoutData)
                self._ticket.cancel.clicked.connect(self.layoutData)
                self.mainWin.hide()
            except Exception as ex:
                print(ex)


        elif obj == "tickets":
            self.tticket = self.winBook.tickets.value()
            ind = self.winBook.coach.currentIndex()
            try:
                cc = td.coach_codes[ind]
                price = td.getTicketPrice(cc, self.distance)
                self.winBook.price.setText("Price : %d Rs."%(price*self.tticket))
            except:
                pass

        elif obj == "coach":
            ind = self.winBook.coach.currentIndex()
            try:
                cc = td.coach_codes[ind]
                price = td.getTicketPrice(cc, self.distance)
                self.winBook.price.setText("Price : %d Rs."%(price*self.tticket))
            except:
                pass
        elif obj == "cancel":
            self.mainWin.close()
            self.show()

    def layoutData(self):
        obj = self.sender().objectName()
        if obj=="print":
            #self.mainWin.close()
            printer = QPrinter(QPrinter.HighResolution)
            dialog = QPrintDialog(printer, self)

            if dialog.exec_() == QPrintDialog.Accepted:
                self._ticket.view.print_(printer)
        elif obj=="cancel":
            self.loutWin.close()
            self.mainWin.close()
            self.show()

    def singleTrain(self):
        self.bookT.setEnabled(False)
        self.cancelR.setEnabled(False)
        tname = self.tname.text()
        tno = self.tno.text()
        try:
            if tname != "":
                vfound = via.viaTrainName(tname)
                found = via.VIA(vfound)
            else:
                vfound = via.viaTrainNo(tno)
                found = via.VIA(vfound)

            if found:
                self.tdetail.setEnabled(True)
                self.trains.setRowCount(1)
                f = found
                self.trains.setItem(0,0,QTableWidgetItem(str(f[0])))
                self.trains.setItem(0,1,QTableWidgetItem(str(f[1])))
                self.trains.setItem(0,2,QTableWidgetItem(str(f[2])))
                self.trains.setItem(0,3,QTableWidgetItem(str(f[3])))
                self.trains.setItem(0,4,QTableWidgetItem(str(f[4])))
                self.trains.setItem(0,5,QTableWidgetItem(str(f[5])))
                self.trains.setItem(0,6,QTableWidgetItem(str(f[6])))
                self.trains.setItem(0,7,QTableWidgetItem(str(f[7])))
                self.trains.setItem(0,8,QTableWidgetItem(str(f[6])))
                self.trains.setItem(0,9,QTableWidgetItem(str(f[7])))
        except Exception as ex:
            print(ex)

    def trainDetails(self):
        try:
            #        self.bookT.clicked.connect(self.booking)
            #        self.search.clicked.connect(self.singleTrain)
            #        self.tdetail.clicked.connect(self.trainDetails)
            #        self.cancelR.clicked.connect(self.cancelReservation)
            

            self.train_name = self.trains.item(0,2).text()
            self.train_no = self.trains.item(0,6).text()

            self._detail = detail.Ui_MainWindow()
            self._detail.setupUi(self.dWin)
            self.dWin.show()
            self.dWin.setStyleSheet(open("ui\\detail_style.css").read())

            self._detail.tview.setHeaderHidden(True)
            self.tmodel = QStandardItemModel()
            self.rootNode = self.tmodel.invisibleRootItem()

            vfound = via.viaTrainNo(self.train_no)
            item = StandardItem(txt="{}    VIA {} STATIONS".format(vfound[0][2], len(vfound)), size=12, bold=True, color=QColor(0,76,255))
            for vf in vfound:
                atime, dtime = vf[0], vf[7]
                at, dt = "",""
                if atime.lower() == "none":
                    at = "Start"
                elif dtime.lower() == "none":
                    dt = "End"

                try:
                    t1 = time.strptime(atime,"%H:%M:%S")
                    at = time.strftime("%I:%M %p",t1)
                except:
                    pass
                try:
                    t2 = time.strptime(dtime,"%H:%M:%S")
                    dt = time.strftime("%I:%M %p",t2)
                except:
                    pass

                if atime==dtime:
                    item1 = StandardItem(txt="Station : {} ({})".format(vf[3], vf[4]), size=10, italic=True, bold=True, color=QColor(255,0,4))
                    item.appendRow(item1)
                    item2 = StandardItem(txt="Arrival Time : {}".format(at), size=10, color=QColor(255,0,230))
                    item1.appendRow(item2)
                    item2 = StandardItem(txt="Departure Time : {}".format(dt), size=10, color=QColor(140,0,255))
                    item1.appendRow(item2)
                else:
                    item1 = StandardItem(txt="Station : {} ({})".format(vf[3], vf[4]), size=10, italic=True, bold=True, color=QColor(15,230,0))
                    item.appendRow(item1)
                    item2 = StandardItem(txt="Arrival Time : {}".format(at), size=10, color=QColor(255,0,230))
                    item1.appendRow(item2)
                    item2 = StandardItem(txt="Departure Time : {}".format(dt), size=10, color=QColor(140,0,255))
                    item1.appendRow(item2)
            self.rootNode.appendRow(item)
            self._detail.tview.setModel(self.tmodel)
            #self._detail.tview.expandAll()
        except Exception as ex:
            print(ex)


    def from_to(self):
        
        source = self.source.text()
        dest = self.dest.text()
        self.stations = [source, dest]
        in1, in2 = td.station_name.index(source), td.station_name.index(dest)
        code, code_to = td.station_code[in1], td.station_code[in2]
        self.station_codes = [code, code_to]

        ar = self.pool.apply_async(hss.trainsFound, (code, code_to, ))
        found = ar.get()
        #found = hss.trainsFound(code, code_to)
        #found = atf.autoFound(code, code_to)


        #time.sleep(1)



        #print(code, code_to)
        if len(found)>0:
            self.bookT.setEnabled(True)
            self.cancelR.setEnabled(True)
            self.tdetail.setEnabled(False)
            self.sresult.setText("{}  Trains Found !   From  {}  To  {}  Station.".format(len(found), source, dest))
            self.trains.setRowCount(len(found))
            for i,f in enumerate(found):
                if f[0].lower() == "none":
                    f[0] = "Start"
                elif f[7].lower() == "none":
                    f[7] = "End"

                try:
                    t1 = time.strptime(f[0],"%H:%M:%S")
                    f[0] = time.strftime("%I:%M %p",t1)
                except:
                    pass
                try:
                    t2 = time.strptime(f[7],"%H:%M:%S")
                    f[7] = time.strftime("%I:%M %p",t2)
                except:
                    pass

                self.trains.setItem(i,0,QTableWidgetItem(str(f[0])))
                self.trains.setItem(i,1,QTableWidgetItem(str(f[1])))
                self.trains.setItem(i,2,QTableWidgetItem(str(f[2])))
                self.trains.setItem(i,3,QTableWidgetItem(str(f[3])))
                self.trains.setItem(i,4,QTableWidgetItem(str(f[4])))
                self.trains.setItem(i,5,QTableWidgetItem(str(f[5])))
                self.trains.setItem(i,6,QTableWidgetItem(str(f[6])))
                self.trains.setItem(i,7,QTableWidgetItem(str(f[7])))
                self.trains.setItem(i,8,QTableWidgetItem(str(dest)))
                self.trains.setItem(i,9,QTableWidgetItem(str(code_to)))
        else:
            self.sresult.setText("{}  Trains Found !   From  {}  To  {}  Station.".format("No", source, dest))
            self.bookT.setEnabled(False)
            self.cancelR.setEnabled(False)

    def save_data(self, info, mode="w"):
        #username, mobile no, train name, train no, station code, destination station code, tickets, coach, price
        uname, mno, tname, tno, scode, dscode, total, coach, price = info
        if mode=="w":
            return self.writeData(tname, tno, total)
        elif mode=="wa":
            return self.writeAdvanceData(info)
        else:
            raise Exception("Error : \nWrong mode {} entered.\nModes available = w, wa".format(mode))

    def writeData(self, tname, tno, total):
        conn = sqlite3.connect('data\\trains.db')
        c = conn.cursor()

        c.execute("SELECT EXISTS (SELECT * FROM train WHERE tname = '{}')".format(tname))
        check = c.fetchall()
        if check[0][0]==1:
            c.execute("SELECT * FROM train WHERE tname = '{}'".format(tname))
            t = c.fetchone()[2]
            t+=total
            c.execute("UPDATE train SET total={} WHERE tname='{}'".format(t, tname))
        else:
            #print(tname, tno, coach, total)
            c.execute("INSERT INTO train VALUES ('{}','{}','{}')".format(tname, tno, total))
        #c.execute("SELECT * FROM train;")

        result = c.fetchall()
        conn.commit()
        conn.close()
        return result

    def writeAdvanceData(self, info):
        #username, mobile no, train name, train no, station code, destination station code, tickets, coach, price
        uname, mno, tname, tno, scode, dscode, total, coach, price = info
        total = int(total)
        price = int(float(price))
        conn = sqlite3.connect('data\\users.db')
        c = conn.cursor()

        c.execute("SELECT EXISTS (SELECT * FROM reserve WHERE username = '{}' AND mobile = '{}' AND tname='{}')".format(uname, mno, tname))
        check = c.fetchall()
        if check[0][0]==1:
            c.execute("SELECT * FROM reserve WHERE username = '{}'".format(uname))
            t = c.fetchone()[6]
            t+=total
            c.execute("UPDATE reserve SET tickets='{}' WHERE username='{}' AND mobile='{}' AND tname='{}'".format(t, uname, mno, tname))
            #c.execute("SELECT * FROM reserve WHERE username = '{}'".format(uname))
        else:
            c.execute("INSERT INTO reserve VALUES ('{}','{}','{}','{}','{}','{}','{}','{}','{}')".format(uname, str(mno), tname, str(tno), scode, dscode, total, coach, price))
        c.execute("SELECT * FROM reserve;")
        result = c.fetchone()

        result = c.fetchall()
        conn.commit()
        conn.close()
        return result


    def readData(self, tname):
        conn = sqlite3.connect("data\\trains.db")
        c = conn.cursor()

        c.execute("SELECT EXISTS (SELECT * FROM train WHERE tname = '{}')".format(tname))
        check = c.fetchall()
        if check[0][0]==1:
            c.execute("SELECT * FROM train WHERE tname='{}'".format(tname))

            total = c.fetchone()[-1]
            conn.commit()
            conn.close()
            return total
        else:
            conn.commit()
            conn.close()
            return 0

    def cancelReservation(self):
        self.hide()
        self.win = QMainWindow()
        self._crv = cancel.Ui_MainWindow()
        self._crv.setupUi(self.win)
        self.win.show()

        reg_ex = QRegExp("[0-9\.\-]{0,10}")
        inp_valid = QRegExpValidator(reg_ex,self._crv.mno)
        self._crv.mno.setValidator(inp_valid)
        self._crv.confirm.setEnabled(False)

        self._crv.search.clicked.connect(self.cancelReservationData)
        self._crv.confirm.clicked.connect(self.confirmCancelReservation)#self.cancelReservationData)
        self._crv.cancel.clicked.connect(self.cancelReservationData)

    def confirmCancelReservation(self):
        def accept():
            self.cancelReservationData("confirm")
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Question)
        msg.setInformativeText("Are you sure ?")
        msg.setWindowTitle("Cancel Reservation")
        msg.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
        retval = msg.exec_()
        if retval==1024:
            accept()
        else:
            pass
    def cancelReservationData(self, *args):
        obj = self.sender().objectName()
        if obj == "search":
            try:
                self._crv.remove.clear()
                #username, mobile no, train name, train no, station code, destination station code, tickets, coach, price
                uname = self._crv.uname.text()
                mno = self._crv.mno.text()
                conn = sqlite3.connect("data\\users.db")
                c = conn.cursor()
                c.execute("SELECT EXISTS (SELECT * FROM reserve WHERE username = '{}' AND mobile = '{}')".format(uname, mno))
                check = c.fetchone()
                if check[0]==1:
                    c.execute("SELECT * FROM reserve WHERE username = '{}' AND mobile = '{}'".format(uname, mno))
                    self.removeData = c.fetchall()

                    self._crv.result.setText("SEARCH RESULT : {} USER FOUND ".format(uname))
                    self._crv.confirm.setEnabled(True)

                    for r in self.removeData:
                        item = QListWidgetItem()
                        text = "Username : "+r[0]+"  Train Name : "+r[2]+"  Tickets : "+str(r[6])
                        item.setText(text)
                        self._crv.remove.addItem(item)
                    #print(r)
                else:
                    self._crv.result.setText("SEARCH RESULT : {} USER NOT FOUND ".format(uname))

                conn.commit()
                conn.close()
            except Exception as ex:
                print(ex)
        elif obj == "confirm" or args[0] == "confirm":
            #username, mobile no, train name, train no, station code, destination station code, tickets, coach, price
            uname = self._crv.uname.text()
            mno = self._crv.mno.text()
            conn = sqlite3.connect("data\\users.db")
            conn2 = sqlite3.connect("data\\trains.db")
            c = conn.cursor()
            c2 = conn2.cursor()
            try:
                ind = self._crv.remove.currentRow()

                info = self.removeData[ind]
                uname, mno, tname = info[0:3]
                total = info[6]
                c.execute("DELETE FROM reserve WHERE username = '{}' AND mobile = '{}' AND tname = '{}'".format(uname, mno, tname))

                c2.execute("SELECT * FROM train WHERE tname = '{}'".format(tname))
                t = c2.fetchone()[2]
                t-=total
                c2.execute("UPDATE train SET total={} WHERE tname='{}'".format(t, tname))
                self._crv.result.setText("RESERVATION CANCELED SUCCESSFULLY !!!".format(uname))
                #time.sleep(0.3)
                self._crv.remove.takeItem(ind)
                if self._crv.remove.count()==0:
                    self._crv.confirm.setEnabled(False)
            except Exception as ex:
                print(ex)
                self.statusbar.showMessage("Select a user from search result then click CONFIRM ")



            conn.commit()
            conn2.commit()
            conn.close()
            conn2.close()
        elif obj == "cancel":
            self.show()
            self.win.close()




if __name__ == "__main__":
    app = QApplication([])

    obj = Window()
    obj.show()

    app.exec_()
