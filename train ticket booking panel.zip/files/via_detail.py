from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5.Qt import QStandardItemModel, QStandardItem
from ui import detail


class StandardItem(QStandardItem):
    def __init__(self, txt="", size=10):
        super().__init__()

        fnt = QFont("arial", size)
        self.setEditable(False)
        self.setFont(fnt)
        self.setText(txt)
        
class window(detail.Ui_MainWindow, QMainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.setStyleSheet(open("ui\\detail_style.css").read())
        self.tview.setHeaderHidden(True)
        self.tmodel = QStandardItemModel()
        self.rootNode = self.tmodel.invisibleRootItem()

        item = StandardItem(txt="dark shadow", size=12)
        item1 = StandardItem(txt="dark")
        item2 = StandardItem(txt="shadow", size=8)
        item.appendRow(item1)
        item1.appendRow(item2)

        self.rootNode.appendRow(item)
        self.tview.setModel(self.tmodel)
        self.tview.expandAll()

        self.tview.doubleClicked.connect(self.getItem)

    def getItem(self, val):
        print(val.data())
        print(val.row())
        print(val.column())


if __name__ == "__main__":
    app = QApplication([])
    obj = window()
    obj.show()
    app.exec_()
