import io, threading
import numpy as np


### ['arrival', 'day', 'train_name', 'station_name', 'station_code', 'id', 'train_number', 'departure']


def filterVia(trains):
    try:
        same = [trains[0]]
        for i,train in enumerate(trains[1::]):
            try:
                if same[i][2] == train[2]:
                    same.append(train)
            except:
                pass
        return same
    except:
        return trains

def viaTrainNo(no):
    files = ["HSS data\\ss1.dat","HSS data\\ss2.dat","HSS data\\ss3.dat","HSS data\\ss4.dat","HSS data\\ss5.dat","HSS data\\ss6.dat"]

    f1 = io.open(file=files[0], mode="rb")
    f2 = io.open(file=files[1], mode="rb")
    f3 = io.open(file=files[2], mode="rb")
    f4 = io.open(file=files[3], mode="rb")
    f5 = io.open(file=files[4], mode="rb")
    f6 = io.open(file=files[5], mode="rb")

    sep = "Ŏ" ### uniqe seperator

    fpointer = [f1, f2, f3, f4, f5, f6]

    found = []
    for f in fpointer:
        for d in f:
            a = d.decode().strip().split(sep)
            if no in a:
                found.append(a)
    found = filterVia(found)
    return found

def viaTrainName(name):
    files = ["HSS data\\ss1.dat","HSS data\\ss2.dat","HSS data\\ss3.dat","HSS data\\ss4.dat","HSS data\\ss5.dat","HSS data\\ss6.dat"]

    f1 = io.open(file=files[0], mode="rb")
    f2 = io.open(file=files[1], mode="rb")
    f3 = io.open(file=files[2], mode="rb")
    f4 = io.open(file=files[3], mode="rb")
    f5 = io.open(file=files[4], mode="rb")
    f6 = io.open(file=files[5], mode="rb")

    sep = "Ŏ" ### uniqe seperator

    fpointer = [f1, f2, f3, f4, f5, f6]

    found = []
    for f in fpointer:
        for d in f:
            a = d.decode().strip().split(sep)
            if name.lower() in a[2].lower():
                found.append(a)
    found = filterVia(found)
    return found

def timeFilter(a):
    h,m,s = a

    while s>=100:
        s -= 100
        m += 1

    while m>=60:
        m -= 60
        h += 1

    if h>23:
        h = 0
        #raise Exception("Wrong time format")
    return [h, m, s]


name = "DELHI - FIROZPUR Passenger"

def reverseTrain(choice, tname=False, rest = 1):
    if tname:
        found = viaTrainName(choice)
    else:
        found = viaTrainNo(choice)

    found.reverse()

    tfound = found
    save = [0,0]
    for i in range(len(tfound)):
        at, dt = tfound[i][0], tfound[i][7]
        j = i-1
        if dt=="None" and at!="None":
            
            t1 = [x for x in at.strip().split(":")]
            
            save = [int(t1[1]), int(t1[2])]
            t1 = [str(int(t1[0])+rest), str(t1[1]), str(t1[2])]
            dt = ":".join(t1)
            at = "None"
            
        elif at=="None" and dt!="None":
            last = tfound[j]
            lat, ldt = tfound[j][0], tfound[j][7]
            oat, odt = found[i][0], found[i][7]
            olat, oldt = found[j][0], found[j][7]
            
            if ldt!="None":
                t1 = [int(x) for x in ldt.strip().split(":")]
                t2 = [int(x) for x in odt.strip().split(":")]
                t3 = [int(x) for x in dt.strip().split(":")]
                #t4 = [int(x) for x in oldt.strip().split(":")]
                

                t = [t1[0], t1[1]+int(np.fabs(save[0]-t3[1])), t1[2]+int(np.fabs(save[1]-t3[2]))]
                t = timeFilter(t)

                tempat = ["00"  if a==0  else str(a) for a in t]

                at = ":".join(tempat)

                dt = "None"

                save = t2[1:3]
        elif dt!="None" and at!="None":
            last = tfound[j]
            lat, ldt = tfound[j][0], tfound[j][7]
            oat, odt = found[i][0], found[i][7]
            olat, oldt = found[j][0], found[j][7]
            if ldt!="None":
                t1 = [int(x) for x in ldt.strip().split(":")]
                t2 = [int(x) for x in odt.strip().split(":")]
                t3 = [int(x) for x in oat.strip().split(":")]
                #t4 = [int(x) for x in oldt.strip().split(":")]
                

                t = [t1[0], t1[1]+int(np.fabs(save[0]-t3[1])), t1[2]+int(np.fabs(save[1]-t3[2]))]
                t = timeFilter(t)

                tempat = ["00"  if a==0  else str(a) for a in t]

                at = ":".join(tempat)

                t = [t[0], t[1]+1, t[2]+t[2]]
                t = timeFilter(t)

                tempat = ["00" if a==0 else str(a) for a in t]

                dt = ":".join(tempat)

                save = t2[1:3]
            
            

        tfound[i][0], tfound[i][7] = at, dt
    return tfound

if __name__ == "__main__":
    no = "02086"
    f = reverseTrain(no)
    print(f)
