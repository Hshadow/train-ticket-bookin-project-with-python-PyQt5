import io

#--------------------------------------------
#    Class              |     Fare(Rs.)     |
#============================================
# First AC (1A)         |       1940        |
# Executive Class (EC)  |       1930        |
# Second AC (2A)        |       1150        |
# First Class (FC)      |       950         |
# Third AC (3A)         |       815         |
# Chair Car (CC)        |       665         |
# Sleeper (SL)          |       315         |
# Second Seating (2S)   |       180         |
#--------------------------------------------


coach_price = {"1A":1940/531, "EC":1930/531, "2A":1150/531, "FC":950/531, "3A":815/531, "CC":665/531, "SL":315/531, "2S":180/531} ### per kilometers

coach_codes = ["1A", "EC", "2A", "FC", "3A", "CC", "SL", "2S"]

coach_class = {"1A":"First AC", "EC":"Executive Class", "2A":"Second AC", "FC":"First Class", "3A":"Third AC", "CC":"Chair Car", "SL":"Sleeper", "2S":"Second Seating"}

coach_names = [v for v in coach_class.values()]

sname, scode = [], []
tname, tno   = [], []

with io.open(file="HSS data\\station_name.dat", mode="rb") as file:
    for d in file:
        t = d.decode().strip("\n")
        sname.append(t)
    file.close()

with io.open(file="HSS data\\station_code.dat", mode="rb") as file:
    for d in file:
        t = d.decode().strip("\n")
        scode.append(t)
    file.close()
    
with io.open(file="HSS data\\train_name.dat", mode="rb") as file:
    for d in file:
        t = d.decode().strip("\n")
        tname.append(t)
    file.close()

with io.open(file="HSS data\\train_no.dat", mode="rb") as file:
    for d in file:
        t = d.decode().strip("\n")
        tno.append(t)
    file.close()

station_name = sname
station_code = scode
train_name = tname
train_no = tno

def getTicketPrice(ccode, distance):
    price = coach_price[ccode]
    return price*distance

if __name__ == "__main__":
    print(tname)
    pass
