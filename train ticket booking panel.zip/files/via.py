import io, multiprocessing


### ['arrival', 'day', 'train_name', 'station_name', 'station_code', 'id', 'train_number', 'departure']

'''files = ["HSS data\\ss1.dat","HSS data\\ss2.dat","HSS data\\ss3.dat","HSS data\\ss4.dat","HSS data\\ss5.dat","HSS data\\ss6.dat"]

f1 = io.open(file=files[0], mode="rb")
f2 = io.open(file=files[1], mode="rb")
f3 = io.open(file=files[2], mode="rb")
f4 = io.open(file=files[3], mode="rb")
f5 = io.open(file=files[4], mode="rb")
f6 = io.open(file=files[5], mode="rb")

sep = "Ŏ" ### uniqe seperator

fpointer = [f1, f2, f3, f4, f5, f6]'''


tno = ["51971", "51972", "51973", "51974", "54791", "54792", "54791"]

def filterVia(trains):
    same = [trains[0]]
    for i,train in enumerate(trains[1::]):
        try:
            if same[i][2] == train[2]:
                same.append(train)
        except:
            pass
    return same

def viaTrainNo(no):
    files = ["HSS data\\ss1.dat","HSS data\\ss2.dat","HSS data\\ss3.dat","HSS data\\ss4.dat","HSS data\\ss5.dat","HSS data\\ss6.dat"]

    f1 = io.open(file=files[0], mode="rb")
    f2 = io.open(file=files[1], mode="rb")
    f3 = io.open(file=files[2], mode="rb")
    f4 = io.open(file=files[3], mode="rb")
    f5 = io.open(file=files[4], mode="rb")
    f6 = io.open(file=files[5], mode="rb")

    sep = "Ŏ" ### uniqe seperator

    fpointer = [f1, f2, f3, f4, f5, f6]

    found = []
    for f in fpointer:
        for d in f:
            a = d.decode().strip().split(sep)
            if no == a[6]:
                found.append(a)
    found = filterVia(found)
    return found

def viaTrainName(name):
    files = ["HSS data\\ss1.dat","HSS data\\ss2.dat","HSS data\\ss3.dat","HSS data\\ss4.dat","HSS data\\ss5.dat","HSS data\\ss6.dat"]

    f1 = io.open(file=files[0], mode="rb")
    f2 = io.open(file=files[1], mode="rb")
    f3 = io.open(file=files[2], mode="rb")
    f4 = io.open(file=files[3], mode="rb")
    f5 = io.open(file=files[4], mode="rb")
    f6 = io.open(file=files[5], mode="rb")

    sep = "Ŏ" ### uniqe seperator

    fpointer = [f1, f2, f3, f4, f5, f6]

    found = []
    for f in fpointer:
        for d in f:
            a = d.decode().strip().split(sep)
            if name.lower() in a[2].lower():
                found.append(a)
    found = filterVia(found)
    return found

def VIA(found):
    f = found[0]
    a = ["-----", f[1], f[2], "-----", "-----", "-----", f[6], "-----"]
    
    return a

if __name__ == "__main__":
    tname = "Mathura Alwar Bhiwani Passenger"
    f = viaTrainName(tname)
    print(f)
    found = viaTrainNo(tno[-1])
    print(found)
