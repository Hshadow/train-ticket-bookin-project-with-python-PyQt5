import pandas as pd
import numpy as np
import io

file = io.open(file="railways\\stations.json", mode="r", encoding="utf-8")

data = pd.read_json(file)

keys = [k for k in data.keys()]

##{'geometry': {'type': 'Point', 'coordinates': [75.4516454, 27.2520587]}, 'type': 'Feature', 'properties': {'state': 'Rajasthan', 'code': 'BDHL', 'name': 'Badhal', 'zone': 'NWR', 'address': 'Kishangarh Renwal, Rajasthan'}}
data = np.array(data[keys])


l = len(data)

final = {}

for i in range(l):
    try:
        name = data[i][1]['properties']['name']
        coord = data[i][1]['geometry']['coordinates']
        code = data[i][1]['properties']['code']

        temp = {code:[name,coord]}
        final.update(temp)
    except:
        pass


f = {"lat_long":final}

df = pd.DataFrame(f,columns=["lat_long",])

df.to_json("lat_long.json")
