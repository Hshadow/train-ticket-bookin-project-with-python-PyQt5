import io, time

try:
    import via
except:
    from files import via

code = 'RAH' ### from station code ramgarh = RAH  (State : Rajasthan, District : alwar, Town : ramgarh)
code_to = "AWR" ### to station code alwar = AWR   (State : Rajasthan, District : alwar)

sep = "Ŏ" ### uniqe seperator

files = ["HSS data\\ss1.dat", "HSS data\\ss2.dat", "HSS data\\ss3.dat", "HSS data\\ss4.dat", "HSS data\\ss5.dat", "HSS data\\ss6.dat"]


f1 = io.open(file=files[0], mode="rb")
f2 = io.open(file=files[1], mode="rb")
f3 = io.open(file=files[2], mode="rb")
f4 = io.open(file=files[3], mode="rb")
f5 = io.open(file=files[4], mode="rb")
f6 = io.open(file=files[5], mode="rb")

fobj = [f1, f2, f3, f4, f5, f6]

tno = []
tname = []

for file in fobj:
    for d in file:
        train = d.decode().strip().split(sep)
        name = train[2]
        tname.append(name)

train_names = []
for n in tname:
    if n not in train_names:
        train_names.append(n)

train_names.sort()

with io.open(file="HSS data\\train_name.dat", mode="wb") as file:
    for d in train_names:
        a = str(d+"\n").encode()
        file.write(a)
    file.close()
