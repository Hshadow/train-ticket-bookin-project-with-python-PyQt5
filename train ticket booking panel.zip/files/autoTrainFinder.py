try:
    import reverseData as rd
    import high_speed_search as hss
except:
    from files import reverseData as rd
    from files import high_speed_search as hss

code = 'RAH' ### from station code
code_to = "AWR" ### ramgarh = RAH, jaipur = JP

def autoFound(code, code_to):
    found = hss.trainsFound(code, code_to)

    ### tname = 2, tno = 6
    rf = []

    for f in found:
        v = rd.reverseTrain(f[6])
        rf.append(v)

    ind1 = []
    ind2 = []
    for i, r in enumerate(rf):
        for k, j in enumerate(r):
            if code in j:
                ind1.append(k)
            if code_to in j:
                ind2.append(k)

    rfound = []
    for ind in range(len(ind1)):
        i1, i2 = ind1[ind], ind2[ind]
        if i1<i2:
            rfound.append(rf[ind][i1])
        else:
            rfound.append(found[ind])
    return rfound

if __name__ == "__main__":
    rfound = autoFound(code, code_to)
    print(rfound)
