import io, time
from multiprocessing.pool import ThreadPool as tp

### ['arrival', 'day', 'train_name', 'station_name', 'station_code', 'id', 'train_number', 'departure']



code = 'RAH'
code_to = "AWR"

sep = "Ŏ" ### uniqe seperator

files = ["HSS data\\ss1.dat", "HSS data\\ss2.dat", "HSS data\\ss3.dat", "HSS data\\ss4.dat", "HSS data\\ss5.dat", "HSS data\\ss6.dat"]

temp = ""

def filterList(l):
    temp = []
    single = []
    for d in l:
        if d==[]:
            pass
        a = "".join(d)
        if a not in single:
            single.append(a)
            temp.append(d)
    return temp
def findTrains(s):
    found = []
    for f in files:
        file = io.open(file = f, mode = "rb")
        pool = tp(processes=1)
        async_result = pool.apply_async(search, (file,s,))
        ret_val = async_result.get()
        found.extend(ret_val)
    return filterList(found)


s = "RAH"
code = "BCT"
code_to = "ADI"

def search(file, s):
    found = []
    for d in file:
        a = d.decode().strip().split(sep)
        if s in a:
            found.append(a)
    file.close()
    return found

def getTrains(fromS, toS):
    same = []
    for i in fromS:
        for j in toS:
            if i[2]==j[2]:
                same.append(i)
    same = filterList(same)
    for s in same:
        if s[0] == s[-1]:
            same.remove(s)
    return same

def trainsFound(code, codeto):
    fromS = findTrains(code)
    toS = findTrains(codeto)
    return getTrains(fromS, toS)


if __name__ == "__main__":
    ret = trainsFound(code, code_to)
    print(ret)
