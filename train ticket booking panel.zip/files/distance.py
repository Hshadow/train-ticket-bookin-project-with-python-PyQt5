from math import radians, sin, cos, acos
import pandas as pd
import numpy as np
import io

def getDistance(start, end):
    start.extend(end)
    slat, slon, elat, elon = start
    dist = 6371.01 * acos(sin(radians(float(slat)))*sin(radians(float(elat))) + cos(radians(float(slat)))*cos(radians(float(elat)))*cos(radians(float(slon)) - radians(float(elon))))
    return dist

def getLatLong(code, code_to):
    file = io.open(file="HSS data\\lat_long.json", mode="r", encoding="utf-8")

    data = pd.read_json(file)

    st = data['lat_long'][code]
    end = data['lat_long'][code_to]

    return st[1],end[1]

def distance(code, code_to):
    try:
        s,e = getLatLong(code, code_to)
        dist = getDistance(s,e)
        return dist
    except:
        return 20.0

if __name__ == "__main__":
    s,e = getLatLong("RAH", "AWR")
    dist = getDistance(s,e)
    print(dist)
